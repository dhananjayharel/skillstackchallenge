import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import 'rxjs/add/operator/mergeMap';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { AlertService, AuthenticationService, CandidateService, EnvironmentService,
        AwsService, OnlineTestService, PushNotificationService } from '../shared/services/index';
import {Observable} from 'rxjs/Rx';
import { OnlineTest } from '../../models/onlinetests.interface';
import { NgbModal, NgbModalOptions, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

@Component({
    selector: 'app-candidate',
    templateUrl: './candidate.component.html',
    styleUrls: ['./candidate.component.scss']
})

export class CandidateComponent implements OnInit, OnDestroy {
    public enrollTestForm: FormGroup;
    public loading = false;
    public submitted: boolean;
    public events: any[] = [];
    public returnUrl: string;
    public _id: string;
    public candidate: any;
    public solutionDetails: any[] = [];
    public showMachineDetails: boolean;
    public environment: any[] = [];
    public statusText: string;
    public launchStarted: boolean;
    public instanceid: string;
    public currentStatus: string;
    public onlineTest: OnlineTest;
    public machinePassword: string;
    public prefetchedMachinePassword: string;
    public testStarted = false;
    public testFinished = false;
    public rdpLink: string;
    public publicIp: string;
    public countDownTimer: string;
    private closeResult: string;
    private modalReference: any;
    public awsLaunchStatusCount = 10;
    public status = 'TEST_LOAD';
	public previewMode = false;
	public _previewTestId: number;
    @ViewChild('launchMachineModal') launchMachineModal: any;

    constructor(
        private _fb: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private authenticationService: AuthenticationService,
        private candidateService: CandidateService,
        private alertService: AlertService,
        private awsService: AwsService,
        private onlineTestService: OnlineTestService,
        private environmentService: EnvironmentService,
        private notifyService: PushNotificationService,
        private modalService: NgbModal) { 
            let currentUrl = window.location.href;
            if (currentUrl.startsWith('https:')) {
                currentUrl = currentUrl.replace('https:', 'http:');
                window.location.href = currentUrl;
            }
        }

    ngOnInit() {
        console.log("init"+this.route.snapshot.params);
		if(this.route.snapshot.paramMap.has('testid')){
		   this.previewMode =true;
		   this._previewTestId = this.route.snapshot.params['testid'];
		   console.log("testid="+this._previewTestId);
           this.loading = true;
           let currentUserData = JSON.parse(localStorage.getItem('currentUserData'));
                  
           this.candidate = {AmiId:"",LaunchedFromStoppedInstance:false,fullname:""};
		   let name = "";
		   if(currentUserData!=null)
				name = currentUserData.fullname;
	   
           if(name.match(/\s/)){
            name =  name.substring(0,name.indexOf(" "));
           }
           this.candidate.fullname = name;
           this.prepareForm(this.candidate);  
		   this.loadTestDetails(this._previewTestId);
		}
		else{
        this._id = this.route.snapshot.params['id'];	
        this.loading = true;
        const filter = { 'where': {'testToken': this._id}};
        this.fetchCandidate(filter);
		}
        this.showMachineDetails = false;
        this.machinePassword = '';
        this.launchStarted = false;
        this.countDownTimer = '300';
    }

    ngOnDestroy() {
        this.notifyService.close();
    }

    openModal(content) {
        let ngbModalOptions: NgbModalOptions = {
            backdrop : 'static',
            keyboard : false,
        };
        this.modalReference = this.modalService.open(content, ngbModalOptions);
        this.modalReference.result.then((result) => {
            this.closeResult = `Closed with: ${result}`;
        }, (reason) => {
            this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        });
    }

    private getDismissReason(reason: any): string {
        if (reason === ModalDismissReasons.ESC) {
            return 'by pressing ESC';
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        } else {
            return  `with: ${reason}`;
        }
    }

    socketServerInit () {
        const solution = {id: '',
            candidateName: '',
            testId: 0,
            instanceId: '',
            pwd: '',
            envId: 0,
            publicIp: '',
            testDuration: 0};

        solution.id = this.candidate.id;
        solution.testId = this.onlineTest.id;
        solution.candidateName = this.candidate.fullname;
        solution.instanceId = this.candidate.instanceId;
        solution.pwd = this.prefetchedMachinePassword;
        solution.envId = this.onlineTest.envId;
        solution.publicIp = this.publicIp;
        solution.testDuration = this.onlineTest['duration'];

        this.notifyService.initializeCandidateConnection(solution);

        this.notifyService.onCandidateMachineSetupComplete().subscribe(obj => {
            console.log(obj);
        });

        this.notifyService.onFinishTest().subscribe(obj => {
            console.log(obj);
            this.stopTest();
			if(!this.previewMode){
				this.alertService.success('Congrats! Your test submission has been successfully sent' +
				' to the recruiters. They will get back to you accordingly after viewing your solution.' +
				' The test is over. You may now close this tab.');
				if (this.onlineTest.videoInterviewQuestions) {
					this.router.navigate(['/video-interview/' + this._id]);
				}
			}
			else{
			this.alertService.success('Test Preview Finished. You may close this tab.');
			if (this.onlineTest.videoInterviewQuestions) {
					this.router.navigate(['/video-interview/' + this._previewTestId + '/' +this._previewTestId]);
				}
			}
			
        });
    }

    onMachineLaunched($event) {
        console.log($event);

         if ($event.publicIp) {
             this.publicIp = $event.publicIp;
             this.socketServerInit();
         }
    }

    fetchCandidate(filter) {


        this.candidateService.getAll(filter)
            .subscribe(
                data => {
                    console.log(data);
                    if (data.length > 0) {
                        this.candidate = data[0];
                    //    if (this.candidate.status === 'invited') {
                            this.prepareForm(this.candidate);
                            if (this.candidate.instanceId.trim().length > 0) {
                                this.instanceid = this.candidate.instanceId;
                            }
							
							
                            this.loadTestDetails(this.candidate.onlineTestId);
                        }  else {
                            this.alertService.success('Test already taken!', true);
                            this.router.navigate(['/login']);
                        }
                    // } else {
                    //    this.router.navigate(['/not-found']);
                    // }
                },
                error => {
                    const err = JSON.parse(error._body);
                    this.alertService.error(err.error.message);
                    this.loading = false;
                });
    }

    prepareForm(candidate) {

        this.enrollTestForm = this._fb.group({
            accept: [null, Validators.compose([Validators.required])],
        });

        // subscribe to form changes
        this.subcribeToFormChanges();

        // get return url from route parameters or default to '/'
        this.returnUrl = '/dashboard';
    }

    subcribeToFormChanges() {
        const myFormStatusChanges$ = this.enrollTestForm.statusChanges;
        const myFormValueChanges$ = this.enrollTestForm.valueChanges;
        myFormStatusChanges$.subscribe(x => this.events.push({ event: 'STATUS_CHANGED', object: x }));
        myFormValueChanges$.subscribe(x => this.events.push({ event: 'VALUE_CHANGED', object: x }));
    }

    onTestEnrolled(enrollTestForm, isValid: boolean) {
        this.submitted = true;

        if (isValid && enrollTestForm.accept) {
            this.doEnroll(enrollTestForm);
        } else {
            this.submitted = false;
        }
    }

    doEnroll(enrollTestForm) {
       //this.status = 'TEST_INITIALIZED';
        //this.openModal(this.launchMachineModal);
        //dj: this.launchInstance();
		//dj: skeep 2'nd screen
		 this.status = 'TEST_LOAD_WINDOW';
        this.showMachineDetails = true;
        this.checkIfStoppedMachineAvailable();
    }

    startTest() {
        // this.loading = true;
        this.status = 'TEST_LOAD_WINDOW';
        this.showMachineDetails = true;
        this.checkIfStoppedMachineAvailable();
    }

    launchInstance() {
        this.statusText = 'Checking....';
        this.instanceid = '';
        const instanceToLaunch = this.onlineTest.environment;

        console.log(instanceToLaunch);
            this.awsService.launchInstance(instanceToLaunch)
            .subscribe(
                data => {
                    console.log('launching instance');
                    this.instanceid = data.instanceId;
                    this.candidate.instanceId = data.instanceId;
                    this.candidate.testStarted = true;

                    this.monitor();
                    this.statusText = 'Launching...';
                    // now update environment

                    this.candidateService.update(this.candidate)
                    .subscribe(
                        data => {
                            console.log('launching instance');
                            console.log(data);
                            this.candidate = data;
                        },
                        error => {
                            const err = JSON.parse(error._body);
                            //dj:commented this.alertService.error(err.error.message);
                            this.loading = false;
                    });

                    },
                error => {
                    const err = JSON.parse(error._body);
                    this.alertService.error(err.error.message);
                    this.loading = false;
                });

    }
	
	//dj:
	    startInstance(instaceId) {
        this.statusText = 'Checking....';
        this.instanceid = '';
        const instanceToLaunch = this.onlineTest.environment;

        console.log(instanceToLaunch);
            this.awsService.startInstance(instaceId)
            .subscribe(
                data => {
                    console.log('launching stopped instance');
                    this.instanceid = instaceId;
                    this.candidate.instanceId = instaceId;
                    this.candidate.testStarted = true;

                    this.monitor();
                    this.statusText = 'Launching...';
                    // now update environment

                    this.candidateService.update(this.candidate)
                    .subscribe(
                        data => {
                            console.log('launching stopped instance');
                            console.log(data);
                            this.candidate = data;
                        },
                        error => {
                            const err = JSON.parse(error._body);
                            //dj:commented this.alertService.error(err.error.message);
                            this.loading = false;
                    });

                    },
                error => {
                    const err = JSON.parse(error._body);
                    this.alertService.error(err.error.message);
                    this.loading = false;
                });

    }

    monitor() {
        this.loading = true;
        const stopTimer$ = Observable.timer(1 * 60 * 1000);
        const timer: any = Observable.timer(50, 4000).takeUntil(stopTimer$);

        const subscription = timer.subscribe(data => {

            if (this.currentStatus === 'initializing') {
                console.log('UNSUBSCRIB');
				//dj: Shifted two methods here bcz sometimes publcip is not available as soon as we launch the machine
                this.prefetchPassword();
                this.launchMachineEntry();
                subscription.unsubscribe();
                this.statusText = 'Done';
            }
            this.checkMachineStatus(subscription);
        });
  }
    checkMachineStatus(subscription) {
        this.awsService.getInstanceStatus(this.instanceid)
        .subscribe(
            data => {
                console.log('x' + data);
                if (data.error) {
                    console.log("in getstatus error retry again");
                    data.state = 'Machine not available';
                    this.currentStatus = 'Remote machine not available';
                    //this.instanceid = '';
                    this.awsLaunchStatusCount--;
                    if(this.awsLaunchStatusCount<0){
                        console.log("aws api error");
                        subscription.unsubscribe();
                        this.instanceid = '';
                    }
                }

                    this.currentStatus = data.state;
                    console.log('this.currentStatus' + this.currentStatus);

                    if (data.state === 'initializing') {
                        this.loading = false;
                    }
                },
        error => {    const err = JSON.parse(error._body);
                    subscription.unsubscribe();
                    this.alertService.error(err.error.message); 
                },
      () => console.log('Monitor Status Complete')
    );

  }

  getPassword() {
      this.machinePassword = this.prefetchedMachinePassword;
  }

  launchMachineEntry() {
      const input = {
            type: 'candidate',
            inviteId: this._id,
            duration: this.onlineTest.duration,
            gitUrl: this.environment['git_url'],
            instanceId: this.instanceid,
            fullname: this.candidate.fullname,
            email: this.candidate.email,
            testId: this.onlineTest.id,
			candidateId: this.candidate.id,
			LaunchedFromStoppedInstance:this.candidate.LaunchedFromStoppedInstance
      };

      this.awsService.addMachinEntry(input)
            .subscribe(
                data => {
                        console.log(data);
                    },
                error => {  const err = JSON.parse(error._body);
                        this.alertService.error(err.error.message);
                    },
        () => console.log('Registered Machine')
        );
  }

  getRDPLink () {
        const inputs = {
            instanceId: this.instanceid,
            testToken: this._id,
            pwd: this.prefetchedMachinePassword
        };
        this.awsService.getRdpLink(inputs)
        .subscribe(
            data => {
                console.log(data);
                this.rdpLink = data.link;
                
            },
            error => {
                const err = JSON.parse(error._body);
                this.alertService.error(err.error.message);
            }
        );
    }

    prefetchPassword() {
        console.log('in prefetch pwd...');
        this.awsService.getPassword(this.onlineTest.environment)
        .subscribe(
        data => {
            console.log('get password=' + data);
            this.prefetchedMachinePassword = data.pwd;
            this.getRDPLink();
        },
        error => {
            const err = JSON.parse(error._body);
            this.alertService.error(err.error.message);}
        );

    }

    showRDPDetails(event) {
        if (event === 'complete') {
            this.launchStarted = true;
            this.testStarted = true;
            this.status = 'TEST_OPEN_WINDOW';
            this.getPublicIp();
            this.updateCandidateTestStatus('ongoing');
            this.modalReference.close();

            setTimeout(function () {
                document.getElementById('testWindow').focus();
            }, 3000);
        }
    }

    getPublicIp() {
        if (this.instanceid) {
            this.environmentService.getPublicIP(this.instanceid)
            .subscribe(
                data => {
                    this.publicIp = data.ip;
                    this.socketServerInit();
                },
                error => {
                    const err = JSON.parse(error._body);
                    this.alertService.error(err.error.message);
                });
        }
    }

    stopTestCountdown(event) {
        if (event === 'complete') {
            const r = confirm('Are you sure you want to mark your Test as Finished?');
            if (r === true) {
                this.stopTest();
            }
        }
    }

    stopTest() {
        this.launchStarted = false;
        this.testStarted = false;
        this.testFinished = true;
        this.status = 'TEST_CLOSE_WINDOW';
        const obj = { ip: ''};
        obj.ip = this.publicIp;
        this.notifyService.triggerFinishTest(obj);
        console.log('create solution ami');
    }

    updateCandidateTestStatus(status) {
        this.candidate.status = status;
        this.candidateService.update(this.candidate)
        .subscribe(
            data => {
                console.log('Set candidate test status to ' + status);
                if (status === 'completed') {
                    this.alertService.success('Congrats! Your test submission has been' +
                        ' successfully sent to the recruiters. They will get back to you' +
                        ' accordingly after viewing your solution. The test is over. You' +
                        ' may now close this tab.');
                }
            },
            error => {
                const err = JSON.parse(error._body);
                this.alertService.error(err.error.message);
                this.loading = false;
        });
    }
	//dj
	checkIfStoppedMachineAvailable(){
        this.awsService.getAvailableStoppedMachines(this.onlineTest.id)
        .subscribe(
            data => {
            console.log(data);
            console.log("testFinished="+this.testFinished);
            console.log("launchStarted="+this.launchStarted);
                if(data.length>0){
                    console.log("Got stopped instance now start that instance:"+data[0].InstanceId);	
                    this.countDownTimer = "100";
                    this.openModal(this.launchMachineModal);
                    this.launchStarted = false;
                    this.testFinished = false;
                    this.testStarted = false;
                    this.candidate.LaunchedFromStoppedInstance = true;
                    this.startInstance(data[0].InstanceId);
                    
                }
                else{
                    console.log("no stopped instance found launch from ami");
                    this.countDownTimer = "300";
                    this.openModal(this.launchMachineModal);
                    this.launchStarted = false;
                    this.testFinished = false;
                    this.testStarted = false;
                    this.launchInstance();					
                }
                
            },
            error => {
                const err = JSON.parse(error._body);
                this.alertService.error(err.error.message);
            });
       
    }
	
	//dj
	loadTestDetails(testId){
	     console.log("loadtest datails");
	     this.onlineTestService.getById(testId)
                            .subscribe(
                                data => {
                                    // this.router.navigate([this.returnUrl]);
                                    // this.alertService.success("The Online test has been saved.", true);                       
                                    console.log(data);
                                    this.onlineTest = data;
                                    this.loading = false;
                                    this.status = 'TEST_INITIAL';
                                    // get the environment details
                                    this.environmentService.getById(data.envId)
                                    .subscribe(
                                        data => {
                                        this.environment = data;
                                        this.onlineTest.environment = data.amiid;
                                        },
                                        error => {}
                                    );
                                },
                                error => {
								    console.log("error");
									this.status = 'NOT_FOUND';
									this.loading = true;
                                    const err = JSON.parse(error._body);
                                    this.alertService.error(err.error.message);
									this.alertService.success('Test not found!', true);
									this.router.navigate(['/login']);
                                    //this.loading = false;
                                }
                            );
	
	
	}
	
	
}
